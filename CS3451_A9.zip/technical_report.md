# Technical Report for Final Project: "Journey"

## 1. Image Overview

This is my final project titled *Journey*. This project symbolizes humanity's boundless curiosity and progress, reflecting on the journey we have taken beyond our home planet and it explores the beauty of the solar system by simulating the orbits of celestial bodies. The project consists of a dynamic 3D scene with planets, the Moon, the Sun, and a colorful starry background, each represented using advanced rendering techniques. These include Phong shading for realistic lighting, normal mapping for surface detail, and particle systems for the starry sky effect. I aimed to create an aesthetically pleasing scene that also showcases the technical depth achieved through the application of various algorithms and graphics techniques learned throughout the course.

### Technical Contributions:
1. **Phong Shading**: Implemented to simulate realistic lighting and reflections on planetary surfaces using ambient, diffuse, and specular components.
2. **Normal Mapping**: Applied to enhance the visual detail of planetary surfaces without increasing polygon counts.
3. **Particle Systems**: Used to simulate a dynamic, flickering starry sky in the background.
4. **Planet Simulation**: Planets are dynamically positioned and scaled around the Sun, with unique texture and material properties to represent their real-world counterparts.

## 2. Technical Implementation Details

### a) Phong Shading Algorithm

Phong shading is a technique used to simulate the way light interacts with a 3D surface. It is composed of three main components: ambient, diffuse, and specular reflections. In my project, these components were used to simulate realistic lighting effects on the planets and other objects in the scene.

#### 1. Ambient Lighting

Ambient lighting represents the background light that uniformly affects all objects in the scene, irrespective of their position. It ensures that surfaces are never completely dark and provides a base level of illumination. In the code, ambient light is calculated using the formula:

```cpp
ambient = light_ambient * material_ambient
```

This term was added to the final color of the object to give it a basic level of illumination that is independent of the light sources' positions.

#### 2. Diffuse Lighting
Diffuse lighting simulates how light scatters across rough surfaces. The light's intensity depends on the angle between the light source and the surface's normal. This is computed using the dot product of the surface normal and the light direction. The formula for diffuse lighting is:
```cpp
diffuse = light_diffuse * material_diffuse * max(dot(N, L), 0)
```
Where `N` is the normalized surface normal vector, and `L` is the normalized light direction vector.

#### 3. Specular Lighting
Specular lighting simulates the bright spots that appear on shiny surfaces when illuminated. This component depends on the reflection of the light source and the view direction. The reflection vector is computed, and the intensity is determined by the angle between the reflected light and the viewer's direction, with a shininess exponent that controls the sharpness of the specular highlight. The formula is:

```cpp
specular = light_specular * material_specular * pow(max(dot(V, R), 0), shininess)
```

Where `V` is the view direction vector, and `R` is the reflection vector calculated by reflecting the light vector across the normal.

#### Final Color Calculation
The final color is the sum of these three components:
```cpp
final color = ambient + diffuse + specular
```

### b) Normal Mapping Algorithm

Normal mapping is a technique used to add surface detail without increasing the polygon count. Instead of directly modifying the geometry, it uses a texture that stores normal vectors (called a normal map), which perturbs the surface normals during shading.

#### 1. TBN Matrix Construction
To correctly apply normal mapping, I first computed the tangent, bitangent, and normal vectors at each vertex in the object’s mesh. These vectors define the surface's orientation and allow the normal map to be applied correctly.

The **tangent** is aligned with the surface's texture coordinates, while the **bitangent** is perpendicular to both the normal and tangent. The **normal** is the surface's inherent direction, usually obtained from the mesh or a normal map.

Afterwards, I constructed a **TBN matrix**, which transforms the normal map's normal vectors (stored in texture space) into world space. This matrix is constructed as follows:

```cpp
TBN = mat3(T, B, N)
```

#### 2. Perturbed Normal Calculation
After reading the normal from the normal map texture, I applied the TBN matrix to perturb the surface normal. This process involves multiplying the normal map’s values by 2.0 and subtracting 1.0 to scale them to the range [-1, 1] and then transforming the normal using the TBN matrix:

```cpp
perturbed_normal = normalize(TBN * normal_map)
```

The perturbed normal is then used in the lighting calculations, giving the object a more detailed surface appearance.

### c) Particle Systems Algorithm

Particle systems are used to simulate dynamic phenomena such as smoke, fire, or in this case, the stars in the background. The stars in the scene are rendered as particles, each with a random position and flickering brightness, creating a dynamic starry sky effect.

#### 1. Random Star Positioning
To simulate the random distribution of stars, I used a random function (`hash2d`) that generated a random 2D vector for each star. The `hash2d` function takes an index and returns two values, which are then scaled and translated to map the positions to the coordinate space of the screen. This ensures that the stars are distributed randomly across the scene.

#### 2. Star Flickering
To make the stars flicker over time, I applied a sine function to the brightness of each particle based on the time (`iTime`). The flickering effect is achieved by multiplying the brightness by the sine of the time variable, which oscillates between 0 and 1. This creates a smooth, periodic flicker effect:

```cpp
brightness *= sin(3.5 * iTime + i) * 0.5 + 0.5;
```

#### 3. Star Color Generation
The color of each star is randomly generated using the `randomColor` function. The `hash2d` function provides random values that are used to generate the red, green, and blue components of the color. This ensures that each star has a unique color, contributing to the overall visual richness of the starry sky.

#### 4. Rendering the Particles
Each star is rendered as a particle by calculating its distance from the camera (via the `uv` coordinate) and adjusting its brightness according to the distance. The `renderParticle` function is responsible for this, and it computes the final color of each star by blending its brightness and color based on the distance.

#### 5. Particle System in the Shader
In the `renderStars` function, I looped through all the stars, calculating their positions, brightness, and color. Each star was rendered as a particle, and the result was accumulated into the final `fragColor`. This produced a rich, dynamic starry background where the stars flicker and shimmer over time, adding depth and atmosphere to the scene.

### d) Planet Simulation

The simulation of planets are an essential part of the project. These objects were positioned and scaled to reflect their real-world counterparts in both size and relative distance from the Sun.

#### 1. Positioning of Planets Around the Sun

The planets in the scene were positioned using a polar coordinate system, with each planet orbiting the Sun at a specific radius. The angle of each planet was dynamically adjusted to simulate its orbit. I used basic trigonometry (cosine and sine functions) to calculate the `x` and `z` positions of the planets, and the `y` position was kept constant at 0 to maintain a 2D orbital plane.

Each planet’s position was defined using the following transformation matrix:

```cpp
Matrix4f t;
t << planetScale, 0, 0, radius * cos(angle),
    0, planetScale, 0, 0,
    0, 0, planetScale, radius * sin(angle),
    0, 0, 0, 1;
planet->Set_Model_Matrix(t);
```

Where:

- `planetScale` defines the scale of each planet.
- `radius` defines the orbital radius.
- `angle` is computed based on the number of planets and their relative orbital positions.

This setup creates a dynamic system where each planet orbits the Sun with realistic distances and positions.

#### 2. Scaling Planets to Their Realistic Sizes
Each planet was scaled relative to its real-world size. The planets in the solar system vary greatly in size, so I defined a set of scale factors for each planet. For example, Earth has a scale factor of 0.6, while Jupiter has a larger scale factor of 1.1. 

#### 3. Planetary Textures and Materials
To simulate the realistic appearance of each planet, I applied textures for each celestial body. These textures were loaded into the shader and mapped onto the planets using the following texture binding process:

```cpp
planet->Add_Texture("tex_color", OpenGLTextureLibrary::Get_Texture("earth_color"));
planet->Add_Texture("tex_normal", OpenGLTextureLibrary::Get_Texture("sphere_normal"));
```
Additionally, each planet had specific material properties defined using the Phong reflection model. For example, Earth had the following material properties:

```cpp
planet->Set_Ka(Vector3f(0.1, 0.1, 0.1));  // Ambient reflection
planet->Set_Kd(Vector3f(0.7, 0.7, 0.7));  // Diffuse reflection
planet->Set_Ks(Vector3f(2, 2, 2));        // Specular reflection
planet->Set_Shininess(128);                // Shininess factor
```

## 3. Solved Challenges

Throughout the implementation, I encountered several challenges, particularly with the shader implementation and the interaction between various lighting effects and textures.

### a) Normal Mapping
One of the challenges was correctly implementing normal mapping. Initially, the normal vectors were not properly perturbed, resulting in flat lighting. The solution was to compute a TBN matrix using the tangent, bitangent, and normal vectors, then apply the normal map using this matrix to perturb the surface normals, achieving more detailed lighting on the surfaces.

### b) Starry Sky and Flickering Effect
Creating a convincing starry sky effect with dynamic flickering was tricky. I solved this by using a random function (`hash2d`) to generate random positions for stars and applying a sine function to make the brightness of the stars oscillate over time, creating a flickering effect. This approach made the stars feel more alive and dynamic.

### c) Lighting Effects
Handling multiple light sources and ensuring proper shading was another challenge. I utilized a structured approach for adding lights to the scene, ensuring each light’s attributes were dynamically passed to the shaders. The complex interaction of lighting with the textures and normals required fine-tuning the lighting equations to produce realistic reflections and shadows.

### d) Performance Optimization
As the scene became more complex with multiple light sources, textures, and shaders, I optimized the performance by carefully managing shader programs and texture bindings to ensure smooth rendering without unnecessary overhead.



